(function ($, window) {
    // Content path validation only for
    // 1. granite/ui/components/coral/foundation/form/pathfield
    // 2. cq/experience-fragments/editor/components/xffield
    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "foundation-autocomplete",
        validate: function (element) {
            var ctaUrl = element.value;
            // Check if pathfield/xffield value is not null then show notification.
            if (ctaUrl !== '' && ctaUrl != null) {
                checkIfPublishedUrl(ctaUrl);
            }
        }
    });

    // Check whether selected content path is published or not.
    function checkIfPublishedUrl(ctaUrl) {
        const JCR_CONTENT = "jcr:content";
        const CQ_LAST_REPLICATION_ACTION = "cq:lastReplicationAction";
        const ACTIVATE = "Activate";
        const INFINITY_JSON = ".infinity.json";
        var url = ctaUrl.concat(INFINITY_JSON);
        $.getJSON(url)
            .done(function (data) {
                var lastReplicationAction = data[JCR_CONTENT][CQ_LAST_REPLICATION_ACTION];
                if (lastReplicationAction !== ACTIVATE) {
                    // Show notification to author if unpublished reference is selected.
                    var message = " You have selected unpublished references. : <br>".concat(ctaUrl.bold());
                    $(window).adaptTo("foundation-ui").notify('', message, 'notice');
                }
            })
    };
})($, window);