(function ($, window) {
    // cq:tag path validation only for cq:dialog
    // Tagfield : cq/gui/components/common/tagspicker
    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: ".js-cq-TagsPickerField .js-coral-pathbrowser-input",
        validate: function (element) {
            var tagPath = element.value;
            if (tagPath !== '' && tagPath != null) {
                checkReplicationStatus(tagPath);
            }
        }
    });

    // Check when coral-Pathbrowser-picker dialog is open.
    $(document).on("click", ".coral-ColumnView-item.is-active", function () {
        var selectedPath = $(this).data("value");
        checkReplicationStatus(selectedPath);
    });

    // Check the replication status of selected tag.
    function checkReplicationStatus(tagPath){
        const CONTENT_PATH_PREFIX = "/content/cq:tags/";
        const INFINITY_JSON = ".infinity.json";
        const CQ_LAST_REPLICATION_ACTION = "cq:lastReplicationAction";
        const ACTIVATE = "Activate";
        if (tagPath.indexOf(CONTENT_PATH_PREFIX)  !== -1) {
            var tagPathUrl = tagPath.concat(INFINITY_JSON);
            $.getJSON(tagPathUrl)
                .done(function (data) {
                    var lastReplicationAction = data[CQ_LAST_REPLICATION_ACTION];
                    if (lastReplicationAction !== ACTIVATE) {
                        var message = " You have Selected Unpublished Tag : " + tagPath.bold();
                         $(window).adaptTo("foundation-ui").notify('', message, 'notice');
                    }
                });
        }
    }
})($, window);