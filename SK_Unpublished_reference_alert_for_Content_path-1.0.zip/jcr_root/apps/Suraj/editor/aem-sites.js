(function () {
    // To Open sites Menu
    $(".aem-start-menu").on('click', function(){
        window.location.href = window.location.origin + "/aem/start.html";
    });

    // To Open Start Menu
    $(".aem-sites-menu").on('click', function(){
        window.location.href = window.location.origin + "/sites.html";
    });

    // To Open XF Menu
    $(".aem-xf-menu").on('click', function(){
        window.location.href = window.location.origin + "/aem/experience-fragments.html";
    });

    //To Open Assets Menu
    $(".aem-assets-menu").on('click', function(){
        window.location.href = window.location.origin + "/assets.html/content/dam";
    });
})();